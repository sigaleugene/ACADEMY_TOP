age=index('Введите возраст');
if((age<=2) && (age>0)){
     alert('Ребенок')
}
else if ((age=>12) && (age<18)){
    alert('Подросток')
}
else if((age>=18) && (age<=60)){
    alert('Взрослый')
}
else if(age>=60){
    alert('Пенсионер')
}
