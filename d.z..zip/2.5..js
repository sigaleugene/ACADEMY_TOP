let exit=1;
while( exit>0){
   let num=+index('Введите цифру:');
   let sign=prompt('Введите знак:');
   let num2=+index('Введите цифру:');
   let a=0;
   if(sign=="+"){
    let a=num+num2;
    alert(num + "+" + num2 + "=" +a);
}
    else if (sign=="-"){
    let a=num-num2;
    alert(num + "-" + num2 + "=" +a);
}
    else if(sign=="*"){
    let a = num * num2;
    alert(num + "*" + num2 + "=" +a);
}
else if(sign=="/"){
    if(num2!==0){
    let a=num/num2;
    alert(num + "/" + num2 + "=" +a);
    }
    else{
        alert('На ноль делить нельзя!');
    }
   

}
else{
    alert('Неверный ввод');
}
    
 exit=+prompt('Введите"0" чтобы закончить"1" чтобы продолжить');
}
