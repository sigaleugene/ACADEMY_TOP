let num=+index('Введите число возводимое в степень:');
let st=+index('Введите степень:');


function func(num,st,) {
    
    if(st<=0){
        return 1;
    }
else{
    return num*func(num,st-1);
}

}
func(num,st);
alert('Число ' + num + "^" + st+"=" + func(num,st,));