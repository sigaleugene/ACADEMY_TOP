let num=+index("Введите число: ");
m=1;
function fun(num) {
   if(num % 10 > m){
m=num %10;
   }
   if(num>10){
    fun(parseInt(num/10));
   }
   return m;
}
alert("Максимальная цифра " + fun(num,m))