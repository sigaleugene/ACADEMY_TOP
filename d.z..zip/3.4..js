let length=index('Введите длину:');
let width=index('Введите ширину:');
function rec(length,width) {
    if(width>0){
        return length*width;
    }
    else if (width==0){
        return length*length;
    }
}
rec();
if(width>0 && width!==length){
    alert('Площадь прямоугольника : '+ length +'x' + width + '=' + rec(length,width));
}
else if(width==0 || width==length){
    alert('Площадь квадрата : '+ length +'x' + length + '=' + rec(length,width));
}