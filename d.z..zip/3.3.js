let num1=+index('Введите число:');
let num2=+index('Введите число:');
let num3=+index('Введите число:');
function number(num1,num2,num3) {
    num3=num1 + "" + num2 + "" + num3;

return num3;
}
number();
alert( number(num1,num2,num3));