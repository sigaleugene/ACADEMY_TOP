year=index('Введите год:');
if((year%400===0)||((year%4===0)&& !(year%100===0))){
    alert(year+' Високосный год')
}
else{
alert(year+' Не високосный год')
}
