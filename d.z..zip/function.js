function index(message){
    do{
        var result=parseInt(prompt(message));
        if(isNaN(result)){
            alert('неверный ввод')
        }
    }
    while(isNaN(result));
    return result;
}