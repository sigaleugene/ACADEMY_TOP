number=+index('Введите начальное число');
number2=+index('Введите конечное число');
sum=number;
while(number<number2){
    number++;
    sum+=number;
    

}


alert('Сумма всех чисел :' + sum);
