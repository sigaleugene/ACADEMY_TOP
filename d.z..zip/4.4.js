let num=+index('Введите порядковый номер числа фибоначи :');
function fun(num) {
    if (num<=1){
        return num;
    }
    return fun(num-1)+fun(num-2);
}
alert("число фибоначи : " + fun(num) + " № " + num);