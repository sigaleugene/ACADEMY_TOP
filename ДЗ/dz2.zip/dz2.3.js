num = +prompt('Введите число :');

document.write("Делители числа " + num +" : ");
for (i=1;i <= num;i++){
  if (num % i == 0){
  document.write(i + ' ; ');
 }}
