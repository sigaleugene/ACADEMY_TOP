num1 = +prompt('Введите начальное число:');
num2 = +prompt('Введите конечное число:');
s=num1;
while (num1 < num2) {
    num1++;
    s += num1;
    
    

}
alert(s);

