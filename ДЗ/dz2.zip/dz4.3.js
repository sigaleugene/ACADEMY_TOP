let a= +prompt('Введите  число : ');
let m = 1;
function s (a) {
if (a % 10 > m) {
  m = a % 10;
}
if (a > 10) {
  s(parseInt(a / 10));
}
return m;
}
alert('Наибольшая цифра - '+s(a))