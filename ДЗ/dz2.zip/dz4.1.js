let a= +prompt('Введите число возводимое в степень : ');
let b= +prompt('Введите степень в которую нудно возвести : ');


function s(a, b) {
  if (b <= 0){ 
    return 1;
  }
  else{
    
    return a * s(a, b - 1);

  }
}
s(a, b);
alert ('Число '+ a +' ^ '+ b + ' = ' + s(a, b));

 