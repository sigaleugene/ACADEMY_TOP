
let a= +prompt('Введите число :');
let b= +prompt('Введите число :');
let c=0;
function counter(a, b,c) {
   
    if (a<b) {

        
   return c=c-1;
   }
   else if (a>b) {
        
        return c=c+1;

    
   }
   else if (a==b) {
        
    return c;


}
   

}
c=counter(a, b,c);
counter();
alert(c);