let a= +prompt('Введите порядковый номер числа Фибоначи : ');
function s(a) {
  if (a <= 1) {
    return a;
  }
  return s(a - 1) + s(a - 2);
}
alert('Число Фибоначи № ' + a +' : ' + s(a));