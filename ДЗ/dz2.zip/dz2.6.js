
let exit= 1;

while(exit>0){
let a= +prompt('Введите цифру :');
let c= prompt('Введите знак :');
let b= +prompt('Введите цифру :');
let s = 0;
if (c=="+" ){

     s = a + b;
    alert(a + ' + ' + b +' = '+ s);   
    }
else if( c=="-" ){
  
     s = a-b;
    alert(a + ' - ' + b +' = '+ s);

    }
else if( c=="*" ){

     s = a*b;
    alert(a + ' * ' + b +' = '+ s);
        
    }
else if( c=="/"){
    if(b!==0){
         s = a/b;
        alert(a + ' / ' + b +' = '+ s);

    }
    else{

        alert("На ноль делить нельзя.");


    }
}
else{

        
    
    
        alert('Неверный ввод.');
    
}


exit= +prompt('Введите "0" чтобы закончить / "1" чтобы продолжить.');

}

