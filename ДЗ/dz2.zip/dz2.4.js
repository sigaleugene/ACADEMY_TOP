let num = +prompt('Введите число :');



for(num1=0; num >= 1 ; num1++){
  
   num = num/10;
   
} ;


alert(num1 + " цифр");