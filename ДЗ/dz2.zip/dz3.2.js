let a= +prompt('Введите число :')
function Factorial(a) {
    if (a == 1 || a == 0) {
      return 1;
    }
    
    return a * Factorial(a - 1);
  }
  alert('факториал числа ' + a +' - '+ Factorial(a)+' .');