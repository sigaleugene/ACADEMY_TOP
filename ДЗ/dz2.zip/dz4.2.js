let a= +prompt('Введите первое число : ');
let b= +prompt('Введите второе число : ');

function s(a, b) {
  if (b === 0) return a;
  return s(b, a % b);
};
s(a, b);
alert ('Наибольший общий делитель чисел '+ a + ' и '+ b +' : ' + s(a, b));

 