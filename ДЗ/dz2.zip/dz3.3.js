let a= prompt('Введите число :');
let b= prompt('Введите число :');
let c= prompt('Введите число :');
function s(a,b,c) {
 
  c=a+b+c;
    return c;
  }
  s();
  alert(s(a, b, c));