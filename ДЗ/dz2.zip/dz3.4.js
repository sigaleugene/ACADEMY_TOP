let a= +prompt('Введите длину : ');
let b= +prompt('Введите ширину : ');

function s(a,b) {
 if(b>0){
  return a*b;

 }
 else if(b==0){

  return a*a;

 }
  
 
  }
  s();
  if(b>0){
    alert('Площадь четырехугольника '+a+' X ' +b+ '=' + s(a, b));
  
   }
   else if(b==0){
  
    alert('Площадь четырехугольника '+a+' X '+a+'=' + s(a, b));
  
   }
    
 