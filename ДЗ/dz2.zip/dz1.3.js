num = +prompt('Введите трехзначное число:');
num1 = num%10;
num2 = ((num - num1)%100)/10;
num3 = (num -(num%100))/100;
if(!(num1===num2) && !(num1===num3) && !(num2===num3)){

alert('В числе ' + num + ' нет одинаковых цифр.')


}
else{

    alert('В числе ' + num + ' есть одинаковые цифры.')

}

