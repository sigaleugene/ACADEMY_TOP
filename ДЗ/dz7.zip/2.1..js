number=+prompt('Введите начальное число');
number2=+prompt('Введите конечное число');
sum=number;
while(number<number2){
    number++;
    sum+=number;
    

}


alert(sum);
