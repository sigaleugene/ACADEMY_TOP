let num=+prompt('Введите число возводимое в степень:');
let st=+prompt('Введите степень:');


function func(num,st,) {
    
    if(st<=0){
        return 1;
    }
else{
    return num*func(num,st-1);
}

}
func(num,st);
alert('Число ' + num + "^" + st+"=" + func(num,st,));