let num=+prompt('Введите число:');
function factorial(num){
    if(num==1 || num==0){return 1;}
    return num * factorial(num-1); 
} 
alert('факториал числа '+ num +'='+ factorial(num) + '.')
    
