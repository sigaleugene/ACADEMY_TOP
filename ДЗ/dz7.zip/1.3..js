number=prompt('Введите трехзначное число');
number1=number%10;
number2=((number-number1)%100)/10;
number3=(number-(number%100))/100;
if(!(number1===number2)&& !(number1===number3)&& !(number2===number3)){
    alert('В числе '+number+' нет одинаковых цифр')
}
else {
    alert('В числе '+number+' есть одинаковые цифры')
}