Number=+prompt('Введите число:');
document.write('Делители этого числа :')
for( i=1;i<=Number;i++){
   if(Number%i==0){
    document.write(i+",");
}
}