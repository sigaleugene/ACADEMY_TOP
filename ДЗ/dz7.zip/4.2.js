let a=+prompt('Введите число: ');
let b=+prompt('Введите число: ');

function fun(a, b){
    if(b===0) return a;
    return fun(b,a%b);
}
fun(a,b);
alert('Наибольший общий делитель чисел ' + a + " и " + b + "=" +  fun(a, b));