let num1=prompt('Введите число:');
let num2=prompt('Введите число:');
let num3=0;
function number(num1,num2,num3) {
    if(num1<num2){
         return num3=num3-1;
}
    else if(num1>num2){
         return num3=num3+1;
}   else if(num1==num2){
         return num3;
}
}
num3=number(num1,num2,num3);
number();
alert(num3);