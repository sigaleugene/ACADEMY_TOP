number=prompt('Введите число: ');
for(number1=0;number>=1;number1++){
    number=number/10;

}

alert('Кол-во цифр в веденном числе: '+number1);