//1
let name = prompt("Введите свое имя: ");
alert("Привет, " + name + "!");

//2
const CURRENT_YEAR = 2024; //Текущий год
let birthday = parseInt(prompt("Введите свой год рождения: "));
let age = CURRENT_YEAR - birthday;
alert("Вам " + age + " лет.");

//3
let sideLength = parseFloat(prompt("Введите длину стороны квадрата: "));
let perimeter = 4 * sideLength;
alert("Периметр данного квадрата " + perimeter);

//4
let radius = parseFloat(prompt("Введите радиус окружности: "));
let square = Math.PI * radius * radius;
alert("Площадь данной окружности " + square.toFixed(2));

//5
let distance = parseFloat(prompt("Введите расстояние в км между двумя городами: "));
let time = parseFloat(prompt("введите время, за которое вы хотите добраться:"));
let speed = distance / time;
alert("Чтобы добраться вовремя, Вам надо двигаться со скоростью " + speed + " км/ч");

//6
const CURRENCY_EXCHANGE_RATE = 0.96; //курс доллара в евро
let dollars = parseFloat(prompt("Введите доллары: "));
let euro = dollars * CURRENCY_EXCHANGE_RATE;
alert(dollars + " $" + " = " + euro.toFixed(2) + " €");

//7
let usbSizeGB = parseFloat(prompt("Введите объем флешки в Гб: "));
let usbSizeMB = usbSizeGB * 1024;
let oneFile = 820; //Размер одного файла
let fileCount = Math.floor(usbSizeMB / oneFile);
alert("На флешку поместятся " + fileCount + " файлов, объемом 820 Мб каждый");

//8
let amount = parseFloat(prompt("Введите сумму денег в кошельке: "));
let priceChocolate = parseFloat(prompt("Введите цену одной шоколадки:"));
let buy = Math.floor(amount / priceChocolate); //всего шоколадок
let change = (amount % priceChocolate); //сдача 
alert("Можно купить " + buy + " шоколадок. При этом сдача составит: " + change + " рублей.");

//9
let number = parseInt(prompt("Введите трехзначное число: "));
var hundreds = Math.floor(number / 100); // сотни
var tens = Math.floor((number % 100) / 10); // десятки
var units = Math.floor(number % 10); // единицы
let m = (units * 100 + tens * 10 + hundreds);
alert(m)

//10
let num = parseInt(prompt("Введите целое число: "));
let answer = (num % 2 === 0) ? " четное число" : " нечетное число";
alert("число " + num + answer);

